//
//  DesertViewController.swift
//  Demo
//
//  Created by Peter Pan on 06/03/2017.
//  Copyright © 2017 Peter Pan. All rights reserved.
//

import UIKit

class DesertViewController: UIViewController {

    @IBAction func showBrownie(_ sender: UIGestureRecognizer) {
       
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "DetailController") as? DetailViewController
        
        
        controller?.detailLabel.text = "使用整顆檸檬汁、檸檬皮拌入法國產區認證的發酵奶油，在口中交織成清爽綿密的滋味。，調整了檸檬的酸度卻仍保留住檸檬香氣，讓怕酸的人也可以大口品嘗。"
        
        self.present(controller!, animated: true, completion: nil )
    }
    
    @IBAction func showTiramisu(_ sender: UIGestureRecognizer) {
        
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "DetailController") as? DetailViewController
        
        print(controller?.detailLabel)
        
        controller?.detailLabel.text = "馬斯卡朋起士的奶香澎潤，配上浸了手沖咖啡的手指餅干，灑上高品質的巧克力粉；採用義式傳統作法卻不加入咖啡酒，是希望大人小孩都能共同經歷這細緻香甜的美妙滋味。"
        
        self.present(controller!, animated: true, completion: nil )
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
